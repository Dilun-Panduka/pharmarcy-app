package com.example.health.excellent.model.enums;

public enum Gender {
    Male,
    Female,
}

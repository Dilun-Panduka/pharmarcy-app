package com.example.health.excellent.model.enums;

public enum EmployeeStatus {
    Working,
    Suspended,
    On_leave,
    Terminated
}

package com.example.health.excellent.controller;

import com.example.health.excellent.model.Employee;
import com.example.health.excellent.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/employee")
public class EmployeeController implements AbstractController<Employee, Integer>{


    @Autowired
    private EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService){
        this.employeeService = employeeService;
    }

    @GetMapping
    public List<Employee> findAll() {
        return employeeService.findAll();
    }


    @PostMapping
    @PutMapping
    public Employee persist(@RequestBody Employee employee) {
        return employeeService.persist(employee);

    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable Integer id) {
        return employeeService.delete(id);

    }

    @PutMapping("/search")
    public List<Employee> search(@RequestBody Employee employee) {
        return employeeService.search(employee);
    }


}

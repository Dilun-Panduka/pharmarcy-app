package com.example.health.excellent.controller;

import com.example.health.excellent.model.Item;
import com.example.health.excellent.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/item")
public class ItemController implements AbstractController<Item, Integer> {

    @Autowired
    private ItemService itemService;

    @GetMapping
    public List<Item> findAll() {
        return itemService.findAll();
    }

    @PostMapping
    public Item persist(@RequestBody Item item) {
        return itemService.persist(item);
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable Integer id) {
        return itemService.delete(id);
    }

    @PutMapping
    public List<Item> search(@RequestBody Item item) {
        return itemService.search(item);
    }
}

package com.example.health.excellent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExcellentApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExcellentApplication.class, args);
	}
}

package com.example.health.excellent.service;

import com.example.health.excellent.model.Employee;
import com.example.health.excellent.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService implements AbstractService<Employee, Integer> {


    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public List<Employee> findAll(){
       return employeeRepository.findAll();

    }

    @Override
    public Employee persist(Employee employee) {
        return employeeRepository.save(employee);

    }

    @Override
    public String delete(Integer id) {
        employeeRepository.deleteById(id);

        return "rrrrrrrrr";
    }

    @Override
    public List<Employee> search(Employee employee) {
        ExampleMatcher matcher = ExampleMatcher
                .matching()
                .withIgnoreCase()
                .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING);
        Example<Employee> example = Example.of(employee, matcher);
        return employeeRepository.findAll(example);
    }






}

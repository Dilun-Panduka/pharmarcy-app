package com.example.health.excellent.controller;

import com.example.health.excellent.model.Supllier;
import com.example.health.excellent.service.SupllierService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/supllier")
public class SupllierController implements AbstractController<Supllier, Integer> {

    @Autowired
    private SupllierService supllierService;

    public SupllierController(SupllierService supllierService){
        this.supllierService = supllierService;

    }
    @GetMapping
    public List<Supllier> findAll() {
        return supllierService.findAll();
    }

    @PostMapping
    public Supllier persist(@RequestBody Supllier supllier) {
        return supllierService.persist(supllier);
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable Integer id) {
        return supllierService.delete(id);
    }

    @PutMapping
    public List<Supllier> search(@RequestBody Supllier supllier) {
        return supllierService.search(supllier);
    }
}

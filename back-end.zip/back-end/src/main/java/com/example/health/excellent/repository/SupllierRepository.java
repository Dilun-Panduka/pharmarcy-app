package com.example.health.excellent.repository;

import com.example.health.excellent.model.Supllier;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SupllierRepository extends JpaRepository<Supllier, Integer> {

}

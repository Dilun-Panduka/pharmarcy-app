package com.example.health.excellent.model.enums;

public enum Category {
    Tablet,
    Capsule,
    Syrup,
    Drops,
    Injection,
    Cream,
    Spray,
    Bulk,
    SurgicalItems

}

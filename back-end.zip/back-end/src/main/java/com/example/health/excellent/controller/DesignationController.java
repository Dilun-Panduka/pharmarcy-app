package com.example.health.excellent.controller;

import com.example.health.excellent.model.enums.Designation;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/designation")
public class DesignationController {
    @GetMapping
    public ResponseEntity<Designation[]> findAll(){
        return ResponseEntity.ok(Designation.values());
    }

}

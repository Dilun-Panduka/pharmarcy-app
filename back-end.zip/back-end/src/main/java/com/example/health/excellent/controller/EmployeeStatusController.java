package com.example.health.excellent.controller;

import com.example.health.excellent.model.enums.EmployeeStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/employeestatus")
public class EmployeeStatusController {
    @GetMapping
    public ResponseEntity<EmployeeStatus[]> findAll(){
        return ResponseEntity.ok(EmployeeStatus.values());

    }
}

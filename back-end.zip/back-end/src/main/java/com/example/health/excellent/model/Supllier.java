package com.example.health.excellent.model;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.Email;

@Entity
@Data
@Table(name = "supllier")
public class Supllier {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "sid")
    private Integer id;

    @Column(name = "name")
    private String supplierName;

    @Column(name = "company")
    private String supplierCompany;

    @Column(name = "address")
    private String supplierAddress;

    @Column(name = "mobile")
    private String supplierMobile;

    @Column(name = "companyNo")
    private String companyNo;

    @Column(name = "email")
    @Email
    private String supplierEmail;

//    @ManyToMany
//    private Item item;
}

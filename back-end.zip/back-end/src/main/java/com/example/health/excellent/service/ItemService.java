package com.example.health.excellent.service;

import com.example.health.excellent.model.Item;
import com.example.health.excellent.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ItemService implements AbstractService<Item, Integer> {
    
    @Autowired
    private ItemRepository itemRepository;
    @Override
    public List<Item> findAll() {
        return itemRepository.findAll();
    }

    @Override
    public Item persist(Item item) {
        return itemRepository.save(item);
    }

    @Override
    public String delete(Integer id) {
        itemRepository.deleteById(id);
        return "Item deleted";
    }

    @Override
    public List<Item> search(Item item) {
        ExampleMatcher matcher = ExampleMatcher
                .matching()
                .withIgnoreCase()
                .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING);
        Example<Item> example = Example.of(item, matcher);
        return itemRepository.findAll(example);
    }
}

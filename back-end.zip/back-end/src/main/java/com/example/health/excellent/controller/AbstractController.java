package com.example.health.excellent.controller;

import org.springframework.http.ResponseEntity;

import java.util.List;

public interface AbstractController<E, I> {

    List<E> findAll();

    E persist(E e);

    String delete(I id);

    List<E> search(E e);



}
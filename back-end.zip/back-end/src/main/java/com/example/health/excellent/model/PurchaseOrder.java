package com.example.health.excellent.model;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "purchseOrder")
public class PurchaseOrder {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String code;
    private String name;
    private Double buyingPrice;
    private Double sellingPrice;
    private Integer qty;
}

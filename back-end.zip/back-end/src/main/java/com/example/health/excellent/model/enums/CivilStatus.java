package com.example.health.excellent.model.enums;

public enum CivilStatus {
    Married,
    Unmarried
}

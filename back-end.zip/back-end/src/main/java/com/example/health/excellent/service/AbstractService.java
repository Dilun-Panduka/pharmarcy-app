package com.example.health.excellent.service;

import java.util.List;

public interface AbstractService<E, I> {

    List<E> findAll();

    E persist(E e);

    String delete(I id);

    List<E> search(E e);

}

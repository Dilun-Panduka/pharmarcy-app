package com.example.health.excellent.model.enums;

public enum Designation {
    Manager,
    Chief_Pharmacist,
    Pharmacist,
    Cashier
}

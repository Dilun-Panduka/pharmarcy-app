package com.example.health.excellent.service;

import com.example.health.excellent.model.Supllier;
import com.example.health.excellent.repository.SupllierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SupllierService implements AbstractService<Supllier, Integer> {

    @Autowired
    private SupllierRepository supllierRepositary;

    @Override
    public List<Supllier> findAll() {
        return supllierRepositary.findAll();
    }

    @Override
    public Supllier persist(Supllier supllier) {
        return supllierRepositary.save(supllier);
    }

    @Override
    public String delete(Integer id) {
        supllierRepositary.deleteById(id);
        return "supllier deleted";
    }

    @Override
    public List<Supllier> search(Supllier supllier) {
        ExampleMatcher matcher = ExampleMatcher
                .matching()
                .withIgnoreCase()
                .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING);
        Example<Supllier> example = Example.of(supllier, matcher);
        return supllierRepositary.findAll(example);
    }
}

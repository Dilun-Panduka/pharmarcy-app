package com.example.health.excellent.controller;

import com.example.health.excellent.model.Customer;
import com.example.health.excellent.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/customer")
public class CustomerController implements AbstractController<Customer, Integer> {

    @Autowired
    private CustomerService customerService;

    public CustomerController(CustomerService customerService){
        this.customerService = customerService;

    }
    @GetMapping
    public List<Customer> findAll() {
        return customerService.findAll();
    }

    @PostMapping
    public Customer persist(@RequestBody Customer customer) {
        return customerService.persist(customer);
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable Integer id) {
        return customerService.delete(id);
    }

    @PutMapping("/search")
    public List<Customer> search(@RequestBody Customer customer) {
        return customerService.search(customer);
    }
}

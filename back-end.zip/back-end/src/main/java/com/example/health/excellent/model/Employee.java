package com.example.health.excellent.model;

import com.example.health.excellent.model.enums.CivilStatus;
import com.example.health.excellent.model.enums.Designation;
import com.example.health.excellent.model.enums.EmployeeStatus;
import com.example.health.excellent.model.enums.Gender;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;
import java.util.Objects;

@Entity
@Data
@Table(name = "employee")
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "EID")
    private Integer id;

    @Column(name = "name")
    private String employeeName;

    @Column(name = "nic")
    private String employeeNic;

    @Column(name = "callingname")
    private String employeeCallingName;

    @Column(name = "mobile")
    private String employeeMobile;

    @Column(name = "doassignment")
    private LocalDate employeeDoassignment;

    @Enumerated(EnumType.STRING)
    private Gender gender;

    @Enumerated(EnumType.STRING)
    private Designation designation;

    @Enumerated(EnumType.STRING)
    private CivilStatus civilStatus;

    @Enumerated(EnumType.STRING)
    private EmployeeStatus employeeStatus;

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (!(object instanceof Employee)) return false;
        Employee employee = (Employee) object;
        return Objects.equals(id, employee.id);
    }
}

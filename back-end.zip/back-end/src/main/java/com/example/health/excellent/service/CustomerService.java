package com.example.health.excellent.service;

import com.example.health.excellent.model.Customer;
import com.example.health.excellent.model.Employee;
import com.example.health.excellent.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService implements AbstractService<Customer, Integer> {

    @Autowired
    private CustomerRepository customerRepositary;

    @Override
    public List<Customer> findAll() {
        return customerRepositary.findAll();
    }

    @Override
    public Customer persist(Customer customer) {
        return customerRepositary.save(customer);
    }

    @Override
    public String delete(Integer id) {
        customerRepositary.deleteById(id);
        return "customer deleted";
    }

    @Override
    public List<Customer> search(Customer customer) {
        ExampleMatcher matcher = ExampleMatcher
                .matching()
                .withIgnoreCase()
                .withStringMatcher(ExampleMatcher.StringMatcher.CONTAINING);
        Example<Customer> example = Example.of(customer, matcher);
        return customerRepositary.findAll(example);
    }
}

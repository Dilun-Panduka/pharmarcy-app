package com.example.health.excellent.model;

import com.example.health.excellent.model.enums.Category;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Data
@Table(name = "item")
public class Item {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "code")
    private String itemCode;

    @Column(name = "name")
    private String itemName;

    @Column(name = "supplierName")
    private String supllierName;

    @Column(name = "buyingPrice")
    private Double buyingPrice;

    @Column(name = "sellingPrice")
    private Double sellingPrice;

    //system entered date,trigger
    @Column(name = "expireDate")
    private LocalDate expireDate;

    @Enumerated(EnumType.STRING)
    private Category category;

//    @ManyToMany
//    private Supllier supllier;


}

package com.example.health.excellent.model;

import com.example.health.excellent.model.enums.Gender;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.Email;
import java.util.Objects;

@Entity
@Data
@Table(name = "customer")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CID")
    private Integer id;

    @Column(name = "name")
    private String customerName;

    @Column(name = "nic")
    private String customerNic;

    @Column(name = "mobile")
    private String customerMobile;

    @Column(name = "land")
    private String customerLand;

    @Column(name = "email")
    private String customerEmail;

    @Column(name = "age")
    private String customerAge;

    @Enumerated(EnumType.STRING)
    private Gender gender;

    @Override
    public boolean equals(Object object) {
        if (this == object) return true;
        if (!(object instanceof Customer)) return false;
        Customer customer = (Customer) object;
        return Objects.equals(id, customer.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
